# Dodge Duo

A real-time two-player browser game. Each player is a 300px-diameter circle in a fixed 1600×900 game world. Isosceles triangle spikes originate from the left and right walls and travel downward toward the players, creating gaps that can be dodged with horizontal movement. Both players share one survival score.

## Features

- Shareable room URLs: `/game/ABCDE`
- Exactly two players per room
- Custom player colors
- Desktop controls: Left Arrow / Right Arrow
- Mobile controls: large left/right touch buttons
- Server-authoritative obstacle generation
- Server-authoritative collision detection
- Circle-vs-triangle collision checks
- Synchronized score and game state
- 3-second countdown
- Shared round loss if either player is hit
- Responsive canvas scaling
- Local movement prediction for smoother controls

## Run locally

1. Install Node.js 18 or newer.
2. In this folder, run:

```bash
npm install
npm start
```

3. Open `http://localhost:3000`.
4. Click **CREATE GAME**.
5. Open the generated room URL on another device connected to the same reachable server.

For testing on two devices on the same Wi-Fi network, use your computer's LAN IP instead of `localhost`, for example:

```text
http://192.168.1.25:3000
```

Your firewall must allow inbound traffic to port 3000.

## Deploy to a public live URL

This project can be deployed to any Node.js host that supports WebSockets, such as Render, Railway, Fly.io, or a VPS.

Typical settings:

- Build command: `npm install`
- Start command: `npm start`
- Node version: 18+
- Required port: use the host-provided `PORT` environment variable (already supported by `server.js`)
- WebSockets: must be enabled

Once deployed, a room link will look like:

```text
https://your-domain.example/game/H7K2P
```

## Project structure

```text
dodge-duo/
├── package.json
├── server.js
├── README.md
└── public/
    ├── index.html
    ├── styles.css
    └── game.js
```

## Game constants

The main values are near the top of `server.js`:

```js
const WORLD = { width: 1600, height: 900 };
const PLAYER_RADIUS = 150;
const PLAYER_SPEED = 620;
const TICK_RATE = 30;
```

A radius of `150` creates the requested 300px-diameter player sprite.
